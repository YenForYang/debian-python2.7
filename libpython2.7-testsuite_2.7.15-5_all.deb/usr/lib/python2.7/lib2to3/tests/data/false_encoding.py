#! /usr/bin/python2.7
print '#coding=0'
